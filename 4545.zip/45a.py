#!/usr/bin/env python
# coding: utf-8

# In[22]:


import sys, os, pprint, glob, re


# In[53]:


IN_PATH = '/home/seki/_seki/DSO/in.txt'

f = open(IN_PATH, 'r')
buf = f.readlines()
f.close()
pprint.pprint(buf)


# In[56]:


outs = []
pre_word = ''
pre_label = ''

word_sep = '_'
item_sep = ' ' 

for i, data in enumerate(buf):
    
    lists = re.sub(r'\n$', '', data).split(' ')
    
    if len(lists) == 2:
        (word, label) = lists
        relation = ''
    elif len(lists) == 3:
        (word, label, relation) = lists
    else:
        print('illegal data line:{}'.format(i + 1))
        continue

    if label == 'O':
        outs.append(word + item_sep + 'O' + item_sep + relation)
    elif label.startswith('S-'):
        outs.append(word + item_sep + label[2:] + item_sep + relation)
    elif label.startswith('B-'):
        pre_word = word
    elif label.startswith('I-'):
        pre_word = pre_word + word_sep + word
    elif label.startswith('E-'):
        pre_word = pre_word + word_sep + word
        outs.append(pre_word + item_sep + label[2:] + item_sep + relation)
    else:
        pass
    
pprint.pprint(outs)


# In[57]:


str_out = ''
word_sep = ' '

for i, data in enumerate(outs):
    
    (word, label, relation) = re.sub(r'\n$', '', data).split(' ')
    
    if label != 'O':
        tag1 = r'<' + label + r'>'
        tag2 = r'</' + label + r'>'
        str_out = str_out + word_sep + tag1 + word + tag2
    else:
        str_out = str_out + word_sep + word

print(str_out)


# In[ ]:




