#!/usr/bin/env python
# -*- coding: utf-8 -*-

import glob, os
import openpyxl

lst = glob.glob('./in/*')
lst.sort()
old_name = ''

wb = openpyxl.Workbook()
sheet = wb.active
sheet.title = 'test_sheet_1'

i = 0
j = 1

for buf in lst:

	if i == 0:
		s_row = i + 1
	else:
		s_row = i + 2
	
	b_name = os.path.basename(buf)
	with open(buf) as f:
		l = f.readlines()
		for tmp in l: 
			tmp = tmp.replace('\n', '')
			tmps = tmp.split(' ')
			if len(tmps) < 2:
				tmps.append('')
			if old_name != '' and old_name != b_name:
				print('\n' + b_name + ' ' + tmps[0] + ' ' + tmps[1])
				i = i + 2
			else:
				print(b_name + ' ' + tmps[0] + ' ' + tmps[1])
				i = i + 1
			old_name = b_name       

			sheet.cell(row=i, column=1).value = b_name
			sheet.cell(row=i, column=3).value = tmps[0]
			sheet.cell(row=i, column=4).value = tmps[1]


	e_row = i
	sheet.merge_cells(start_row=s_row, start_column=2, end_row=e_row, end_column=2)
	#print(str(s_row) + ', ' + str(e_row))

wb.save('test.xlsx')

# EOF #
